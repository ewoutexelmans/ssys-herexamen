# Online Sources  
[Servo motor documentation sheet.](https://www.parallax.com/sites/default/files/downloads/900-00008-Continuous-Rotation-Servo-Documentation-v2.2.pdf)  
[Arduino's servo library reference.](https://www.arduino.cc/en/Reference/Servo)  
[nRF24L01 library documentation.](http://tmrh20.github.io/RF24/)  
[How to convert a string to a floating point.](https://www.thinkage.ca/english/gcos/expl/c/lib/atof.html)  
