# ssys-herexamen
(temporary) github for re-examination of smart-systems
